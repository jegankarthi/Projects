const funcs = {
  foo: function () {
    alert("foo");
  },
  bar: function () {
    alert("bar");
  },
};
const f1 = function (s) {
  alert(s);
};
const f2 = function (s) {
  alert(s);
};
const hello = "<h1>hello </h1>";
export {
  hello,
  funcs,
  f1,
  f2
};